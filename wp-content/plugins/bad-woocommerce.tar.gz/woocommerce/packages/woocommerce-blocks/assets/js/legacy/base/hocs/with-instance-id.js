export { withInstanceId } from '@wordpress/compose';

export const ROUND_UP = 'ROUND_UP';
export const ROUND_DOWN = 'ROUND_DOWN';
